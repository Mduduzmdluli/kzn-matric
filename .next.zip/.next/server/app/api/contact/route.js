"use strict";(()=>{var e={};e.id=386,e.ids=[386],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},43379:(e,r,s)=>{s.r(r),s.d(r,{originalPathname:()=>m,patchFetch:()=>x,requestAsyncStorage:()=>c,routeModule:()=>p,serverHooks:()=>v,staticGenerationAsyncStorage:()=>u});var o={};s.r(o),s.d(o,{POST:()=>l});var t=s(49303),i=s(88716),a=s(60670),d=s(87070),n=s(55245);async function l(e){try{let{name:r,email:s,phone:o,subject:t,message:i}=await e.json();if(!r||!s||!t||!i)return d.NextResponse.json({error:"Missing required fields"},{status:400});console.log("SMTP Config:",{host:process.env.SMTP_HOST,port:process.env.SMTP_PORT,user:process.env.SMTP_USER,passExists:!!process.env.SMTP_PASS});let a=process.env.SMTP_PASS?.replace(/\s/g,"")||"",l=parseInt(process.env.SMTP_PORT||"465"),p=n.createTransport({host:process.env.SMTP_HOST,port:l,secure:465===l,auth:{user:process.env.SMTP_USER,pass:a},connectionTimeout:15e3,greetingTimeout:15e3,socketTimeout:15e3});console.log("Verifying SMTP connection..."),await p.verify(),console.log("SMTP connection verified");let c={from:`"KN Matric Excellence Contact Form" <${process.env.SMTP_USER}>`,to:process.env.CONTACT_EMAIL_TO||"support@knmatricexcellence.co.za",replyTo:s,subject:`Contact Form: ${t}`,html:`
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.6;
              color: #333;
            }
            .container {
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
            }
            .header {
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              color: white;
              padding: 20px;
              border-radius: 8px 8px 0 0;
            }
            .content {
              background: #f9f9f9;
              padding: 20px;
              border: 1px solid #ddd;
              border-top: none;
              border-radius: 0 0 8px 8px;
            }
            .field {
              margin-bottom: 15px;
              padding: 10px;
              background: white;
              border-left: 4px solid #667eea;
            }
            .label {
              font-weight: bold;
              color: #667eea;
              margin-bottom: 5px;
            }
            .message-box {
              background: white;
              padding: 15px;
              border-radius: 5px;
              border: 1px solid #ddd;
              margin-top: 10px;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h2 style="margin: 0;">New Contact Form Message</h2>
              <p style="margin: 5px 0 0 0; opacity: 0.9;">From KN Matric Excellence Website</p>
            </div>
            <div class="content">
              <div class="field">
                <div class="label">Name:</div>
                <div>${r}</div>
              </div>

              <div class="field">
                <div class="label">Email:</div>
                <div><a href="mailto:${s}">${s}</a></div>
              </div>

              <div class="field">
                <div class="label">Phone:</div>
                <div>${o||"Not provided"}</div>
              </div>

              <div class="field">
                <div class="label">Subject:</div>
                <div>${t}</div>
              </div>

              <div class="field">
                <div class="label">Message:</div>
                <div class="message-box">${i.replace(/\n/g,"<br>")}</div>
              </div>

              <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 12px;">
                <p>This email was sent from the contact form on the KN Matric Excellence website.</p>
                <p>To reply, simply respond to this email or use the email address provided above.</p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `};console.log("Sending email...");let u=await p.sendMail(c);return console.log("Email sent successfully:",u.messageId),d.NextResponse.json({message:"Email sent successfully"},{status:200})}catch(e){return console.error("Error sending email:",e),console.error("Error details:",{message:e.message,code:e.code,command:e.command,response:e.response}),d.NextResponse.json({error:"Failed to send email",details:e.message,code:e.code},{status:500})}}let p=new t.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:"app/api/contact/route"},resolvedPagePath:"c:\\Projects\\kzm-matric-new\\src\\app\\api\\contact\\route.ts",nextConfigOutput:"",userland:o}),{requestAsyncStorage:c,staticGenerationAsyncStorage:u,serverHooks:v}=p,m="/api/contact/route";function x(){return(0,a.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:u})}}};var r=require("../../../webpack-runtime.js");r.C(e);var s=e=>r(r.s=e),o=r.X(0,[948,972,245],()=>s(43379));module.exports=o})();