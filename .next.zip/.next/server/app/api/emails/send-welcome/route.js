"use strict";(()=>{var e={};e.id=247,e.ids=[247],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},94991:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>h,patchFetch:()=>x,requestAsyncStorage:()=>u,routeModule:()=>p,serverHooks:()=>m,staticGenerationAsyncStorage:()=>d});var o={};t.r(o),t.d(o,{POST:()=>c});var i=t(49303),a=t(88716),s=t(60670),n=t(87070),l=t(55245);async function c(e){try{let{to:r,studentName:t}=await e.json(),o=l.createTransport({host:process.env.SMTP_HOST||"smtp.gmail.com",port:parseInt(process.env.SMTP_PORT||"587"),secure:!1,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}}),i={from:`"KZN Matric Excellence" <${process.env.SMTP_USER}>`,to:r,subject:"Welcome to KZN Matric Excellence! \uD83C\uDF93",html:`
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
            .highlight { background: #fff; padding: 15px; border-left: 4px solid #667eea; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎓 Welcome to KZN Matric Excellence!</h1>
            </div>
            <div class="content">
              <p>Dear ${t},</p>

              <p>Congratulations! You have successfully registered with KZN Matric Excellence.</p>

              <div class="highlight">
                <strong>What happens next?</strong>
                <ul>
                  <li>Our team is reviewing your application</li>
                  <li>You will receive a confirmation email within 24-48 hours</li>
                  <li>Once approved, you'll get access to your student portal</li>
                  <li>Course materials and schedules will be provided</li>
                </ul>
              </div>

              <p><strong>Important Information:</strong></p>
              <ul>
                <li>Keep your login credentials safe</li>
                <li>Check your email regularly for updates</li>
                <li>Contact us if you have any questions</li>
              </ul>

              <p>We're excited to help you achieve your matric excellence goals!</p>

              <a href="https://online.matricexcellence.co.za/signin" class="button">Login to Your Account</a>

              <p>Best regards,<br>
              <strong>The KZN Matric Excellence Team</strong></p>
            </div>
            <div class="footer">
              <p>📧 Email: support@knmatricexcellence.co.za<br>
              📱 Phone: +27 123 456 789<br>
              🌐 Website: <a href="https://online.matricexcellence.co.za">online.matricexcellence.co.za</a></p>
              <p style="font-size: 12px; color: #999;">
                This is an automated message. Please do not reply to this email.
              </p>
            </div>
          </div>
        </body>
        </html>
      `,text:`
        Dear ${t},

        Congratulations! You have successfully registered with KZN Matric Excellence.

        What happens next?
        - Our team is reviewing your application
        - You will receive a confirmation email within 24-48 hours
        - Once approved, you'll get access to your student portal
        - Course materials and schedules will be provided

        Important Information:
        - Keep your login credentials safe
        - Check your email regularly for updates
        - Contact us if you have any questions

        We're excited to help you achieve your matric excellence goals!

        Login: https://online.matricexcellence.co.za/signin

        Best regards,
        The KZN Matric Excellence Team

        Email: support@knmatricexcellence.co.za
        Phone: +27 123 456 789
        Website: online.matricexcellence.co.za
      `};return await o.sendMail(i),n.NextResponse.json({success:!0,message:"Welcome email sent successfully"},{status:200})}catch(e){return console.error("Error sending welcome email:",e),n.NextResponse.json({success:!1,error:e.message},{status:500})}}let p=new i.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/emails/send-welcome/route",pathname:"/api/emails/send-welcome",filename:"route",bundlePath:"app/api/emails/send-welcome/route"},resolvedPagePath:"c:\\Projects\\kzm-matric-new\\src\\app\\api\\emails\\send-welcome\\route.ts",nextConfigOutput:"",userland:o}),{requestAsyncStorage:u,staticGenerationAsyncStorage:d,serverHooks:m}=p,h="/api/emails/send-welcome/route";function x(){return(0,s.patchFetch)({serverHooks:m,staticGenerationAsyncStorage:d})}}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),o=r.X(0,[948,972,245],()=>t(94991));module.exports=o})();