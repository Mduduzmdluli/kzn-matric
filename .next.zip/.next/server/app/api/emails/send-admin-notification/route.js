"use strict";(()=>{var t={};t.id=404,t.ids=[404],t.modules={20399:t=>{t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:t=>{t.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:t=>{t.exports=require("child_process")},84770:t=>{t.exports=require("crypto")},80665:t=>{t.exports=require("dns")},17702:t=>{t.exports=require("events")},92048:t=>{t.exports=require("fs")},32615:t=>{t.exports=require("http")},35240:t=>{t.exports=require("https")},98216:t=>{t.exports=require("net")},19801:t=>{t.exports=require("os")},55315:t=>{t.exports=require("path")},76162:t=>{t.exports=require("stream")},82452:t=>{t.exports=require("tls")},17360:t=>{t.exports=require("url")},21764:t=>{t.exports=require("util")},71568:t=>{t.exports=require("zlib")},55902:(t,e,r)=>{r.r(e),r.d(e,{originalPathname:()=>h,patchFetch:()=>g,requestAsyncStorage:()=>l,routeModule:()=>m,serverHooks:()=>u,staticGenerationAsyncStorage:()=>p});var i={};r.r(i),r.d(i,{POST:()=>c});var n=r(49303),o=r(88716),a=r(60670),s=r(87070),d=r(55245);async function c(t){try{let{student:e,school:r,courses:i,parent:n,documents:o}=await t.json(),a=d.createTransport({host:process.env.SMTP_HOST||"smtp.gmail.com",port:parseInt(process.env.SMTP_PORT||"587"),secure:!1,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}}),c=i.join(", "),m=`Online - ${e.firstName} ${e.lastName} - ${e.idNumber}`,l=[];if(o.idDocument){let t=o.idDocument.data.split(",")[1];l.push({filename:o.idDocument.name,content:t,encoding:"base64",contentType:o.idDocument.type})}if(o.matricDocument){let t=o.matricDocument.data.split(",")[1];l.push({filename:o.matricDocument.name,content:t,encoding:"base64",contentType:o.matricDocument.type})}let p={from:`"KZN Matric Excellence Registration" <${process.env.SMTP_USER}>`,to:"admin@matricexcellence.co.za",subject:m,attachments:l,html:`
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
            .section { background: #f9f9f9; margin: 20px 0; padding: 20px; border-left: 4px solid #2563eb; }
            .section h2 { margin-top: 0; color: #2563eb; }
            table { width: 100%; border-collapse: collapse; }
            td { padding: 8px; border-bottom: 1px solid #ddd; }
            td:first-child { font-weight: bold; width: 200px; }
            .documents { background: #fff3cd; padding: 15px; margin: 20px 0; border-left: 4px solid #ffc107; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎓 New Student Registration</h1>
              <p>A new student has registered online</p>
            </div>

            <div class="section">
              <h2>👤 Student Information</h2>
              <table>
                <tr>
                  <td>Full Name:</td>
                  <td>${e.firstName} ${e.lastName}</td>
                </tr>
                <tr>
                  <td>ID Number:</td>
                  <td><strong>${e.idNumber}</strong></td>
                </tr>
                <tr>
                  <td>Email:</td>
                  <td>${e.email}</td>
                </tr>
                <tr>
                  <td>Phone:</td>
                  <td>${e.phone}</td>
                </tr>
                <tr>
                  <td>Gender:</td>
                  <td>${e.gender}</td>
                </tr>
                <tr>
                  <td>Nationality:</td>
                  <td>${e.nationality}</td>
                </tr>
              </table>
            </div>

            <div class="section">
              <h2>🏫 School Information</h2>
              <table>
                <tr>
                  <td>School Name:</td>
                  <td>${r.name}</td>
                </tr>
                <tr>
                  <td>Centre Number:</td>
                  <td>${r.centreNo}</td>
                </tr>
                <tr>
                  <td>City:</td>
                  <td>${r.city}</td>
                </tr>
              </table>
            </div>

            <div class="section">
              <h2>📚 Interested Courses</h2>
              <p><strong>${c}</strong></p>
            </div>

            <div class="section">
              <h2>👨‍👩‍👧 Parent/Guardian Information</h2>
              <table>
                <tr>
                  <td>Full Name:</td>
                  <td>${n.firstName} ${n.lastName}</td>
                </tr>
                <tr>
                  <td>Relationship:</td>
                  <td>${n.relationship}</td>
                </tr>
                <tr>
                  <td>Phone:</td>
                  <td>${n.phone}</td>
                </tr>
              </table>
            </div>

            <div class="documents">
              <h2>📎 Document Attachments</h2>
              <p><strong>📧 Attached to this email:</strong></p>
              <ul>
                <li><strong>ID Document:</strong> ${o.idDocument?`✓ ${o.idDocument.name} (attached)`:"❌ Not provided"}</li>
                <li><strong>Matric Certificate:</strong> ${o.matricDocument?`✓ ${o.matricDocument.name} (attached)`:"❌ Not provided"}</li>
              </ul>
              ${o.idDocument&&o.matricDocument?"<p><em>✅ All documents attached - please review below.</em></p>":`<p><em>⚠️ Contact student at ${e.email} or ${e.phone} for missing documents.</em></p>`}
            </div>

            <div class="footer">
              <p><strong>Action Required:</strong></p>
              <p>Please review this registration and approve or contact the student if additional information is needed.</p>
              <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;">
              <p style="font-size: 12px; color: #999;">
                This is an automated notification from the KZN Matric Excellence registration system.<br>
                Registration received at: ${new Date().toLocaleString("en-ZA",{timeZone:"Africa/Johannesburg"})}
              </p>
            </div>
          </div>
        </body>
        </html>
      `,text:`
        NEW STUDENT REGISTRATION
        ========================

        STUDENT INFORMATION
        -------------------
        Full Name: ${e.firstName} ${e.lastName}
        ID Number: ${e.idNumber}
        Email: ${e.email}
        Phone: ${e.phone}
        Gender: ${e.gender}
        Nationality: ${e.nationality}

        SCHOOL INFORMATION
        ------------------
        School Name: ${r.name}
        Centre Number: ${r.centreNo}
        City: ${r.city}

        INTERESTED COURSES
        ------------------
        ${c}

        PARENT/GUARDIAN INFORMATION
        ---------------------------
        Full Name: ${n.firstName} ${n.lastName}
        Relationship: ${n.relationship}
        Phone: ${n.phone}

        DOCUMENT ATTACHMENTS
        --------------------
        ID Document: ${o.idDocument?`✓ ${o.idDocument.name} (attached)`:"❌ Not provided"}
        Matric Certificate: ${o.matricDocument?`✓ ${o.matricDocument.name} (attached)`:"❌ Not provided"}

        ${o.idDocument&&o.matricDocument?"✓ All documents attached to this email.":`ACTION REQUIRED: Contact student at ${e.email} or ${e.phone} for missing documents.`}

        Registration received at: ${new Date().toLocaleString("en-ZA",{timeZone:"Africa/Johannesburg"})}
      `};return await a.sendMail(p),s.NextResponse.json({success:!0,message:"Admin notification sent successfully"},{status:200})}catch(t){return console.error("Error sending admin notification:",t),s.NextResponse.json({success:!1,error:t.message},{status:500})}}let m=new n.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/emails/send-admin-notification/route",pathname:"/api/emails/send-admin-notification",filename:"route",bundlePath:"app/api/emails/send-admin-notification/route"},resolvedPagePath:"c:\\Projects\\kzm-matric-new\\src\\app\\api\\emails\\send-admin-notification\\route.ts",nextConfigOutput:"",userland:i}),{requestAsyncStorage:l,staticGenerationAsyncStorage:p,serverHooks:u}=m,h="/api/emails/send-admin-notification/route";function g(){return(0,a.patchFetch)({serverHooks:u,staticGenerationAsyncStorage:p})}}};var e=require("../../../../webpack-runtime.js");e.C(t);var r=t=>e(e.s=t),i=e.X(0,[948,972,245],()=>r(55902));module.exports=i})();