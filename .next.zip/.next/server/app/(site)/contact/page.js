(()=>{var e={};e.id=198,e.ids=[198],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},55315:e=>{"use strict";e.exports=require("path")},17360:e=>{"use strict";e.exports=require("url")},14736:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>i.a,__next_app__:()=>p,originalPathname:()=>m,pages:()=>c,routeModule:()=>u,tree:()=>d}),r(17762),r(32029),r(22396);var a=r(23191),s=r(88716),o=r(37922),i=r.n(o),n=r(95231),l={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>n[e]);r.d(t,l);let d=["",{children:["(site)",{children:["contact",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,17762)),"c:\\Projects\\kzm-matric-new\\src\\app\\(site)\\contact\\page.tsx"]}]},{}]},{metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,73881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(r.bind(r,32029)),"c:\\Projects\\kzm-matric-new\\src\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(r.bind(r,22396)),"c:\\Projects\\kzm-matric-new\\src\\app\\not-found.tsx"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,73881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],c=["c:\\Projects\\kzm-matric-new\\src\\app\\(site)\\contact\\page.tsx"],m="/(site)/contact/page",p={require:r,loadChunk:()=>Promise.resolve()},u=new a.AppPageRouteModule({definition:{kind:s.x.APP_PAGE,page:"/(site)/contact/page",pathname:"/contact",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},8096:(e,t,r)=>{Promise.resolve().then(r.bind(r,38493))},5932:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});let a=(0,r(62881).Z)("mail",[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]])},42887:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});let a=(0,r(62881).Z)("phone",[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]])},38493:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>h});var a=r(10326),s=r(42887),o=r(5932),i=r(77636),n=r(62881);let l=(0,n.Z)("clock",[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]),d=(0,n.Z)("send",[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]),c=(0,n.Z)("message-circle",[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]]);var m=r(14323),p=r(17577),u=r(40381);let x=[{icon:s.Z,title:"Phone",details:["+27 123 456 789","+27 987 654 321"],color:"bg-blue-50 dark:bg-blue-900/20",iconColor:"text-blue-600 dark:text-blue-400"},{icon:o.Z,title:"Email",details:["info@knmatricexcellence.co.za","support@knmatricexcellence.co.za"],color:"bg-green-50 dark:bg-green-900/20",iconColor:"text-green-600 dark:text-green-400"},{icon:i.Z,title:"Location",details:["KwaZulu-Natal","South Africa"],color:"bg-orange-50 dark:bg-orange-900/20",iconColor:"text-orange-600 dark:text-orange-400"},{icon:l,title:"Working Hours",details:["Mon - Fri: 8:00 AM - 6:00 PM","Sat: 9:00 AM - 2:00 PM"],color:"bg-purple-50 dark:bg-purple-900/20",iconColor:"text-purple-600 dark:text-purple-400"}];function h(){let[e,t]=(0,p.useState)({name:"",email:"",phone:"",subject:"",message:""}),[r,s]=(0,p.useState)(!1),o=async r=>{r.preventDefault(),s(!0);try{if(!(await fetch("/api/contact",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:e.name,email:e.email,phone:e.phone||"",subject:e.subject,message:e.message})})).ok)throw Error("Failed to send message");u.ZP.success("Message sent successfully! We will get back to you soon."),t({name:"",email:"",phone:"",subject:"",message:""})}catch(e){console.error("Email sending error:",e),u.ZP.error("Failed to send message. Please try again or email us directly at support@knmatricexcellence.co.za")}finally{s(!1)}},i=r=>{t({...e,[r.target.name]:r.target.value})};return(0,a.jsxs)(a.Fragment,{children:[a.jsx(m.Z,{pageName:"Contact Us",pageDescription:"Get in touch with us - we're here to help you achieve matric excellence"}),a.jsx("section",{className:"py-16 md:py-20 lg:py-24",children:(0,a.jsxs)("div",{className:"container mx-auto lg:max-w-screen-xl md:max-w-screen-md px-4",children:[a.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16",children:x.map((e,t)=>{let r=e.icon;return(0,a.jsxs)("div",{className:`${e.color} p-6 rounded-lg text-center hover:shadow-lg transition-shadow`,children:[a.jsx("div",{className:"inline-flex items-center justify-center w-14 h-14 rounded-full bg-white dark:bg-dark-2 mb-4 shadow-sm",children:a.jsx(r,{className:e.iconColor,size:28})}),a.jsx("h3",{className:"text-lg font-bold text-dark dark:text-white mb-3",children:e.title}),e.details.map((e,t)=>a.jsx("p",{className:"text-body-secondary text-sm mb-1",children:e},t))]},t)})}),(0,a.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-12",children:[(0,a.jsxs)("div",{className:"bg-white dark:bg-dark-2 p-8 rounded-lg shadow-lg border border-stroke dark:border-stroke-dark",children:[(0,a.jsxs)("div",{className:"mb-6",children:[a.jsx("h2",{className:"text-3xl font-bold text-dark dark:text-white mb-2",children:"Send us a Message"}),a.jsx("p",{className:"text-body-secondary",children:"Fill out the form below and we'll get back to you as soon as possible."})]}),(0,a.jsxs)("form",{onSubmit:o,className:"space-y-6",children:[(0,a.jsxs)("div",{children:[a.jsx("label",{htmlFor:"name",className:"block text-sm font-medium text-dark dark:text-white mb-2",children:"Full Name *"}),a.jsx("input",{type:"text",id:"name",name:"name",value:e.name,onChange:i,required:!0,className:"w-full px-4 py-3 rounded-lg border border-stroke dark:border-stroke-dark bg-transparent text-dark dark:text-white outline-none focus:border-primary transition",placeholder:"Enter your full name"})]}),(0,a.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[(0,a.jsxs)("div",{children:[a.jsx("label",{htmlFor:"email",className:"block text-sm font-medium text-dark dark:text-white mb-2",children:"Email Address *"}),a.jsx("input",{type:"email",id:"email",name:"email",value:e.email,onChange:i,required:!0,className:"w-full px-4 py-3 rounded-lg border border-stroke dark:border-stroke-dark bg-transparent text-dark dark:text-white outline-none focus:border-primary transition",placeholder:"your@email.com"})]}),(0,a.jsxs)("div",{children:[a.jsx("label",{htmlFor:"phone",className:"block text-sm font-medium text-dark dark:text-white mb-2",children:"Phone Number"}),a.jsx("input",{type:"tel",id:"phone",name:"phone",value:e.phone,onChange:i,className:"w-full px-4 py-3 rounded-lg border border-stroke dark:border-stroke-dark bg-transparent text-dark dark:text-white outline-none focus:border-primary transition",placeholder:"+27 123 456 789"})]})]}),(0,a.jsxs)("div",{children:[a.jsx("label",{htmlFor:"subject",className:"block text-sm font-medium text-dark dark:text-white mb-2",children:"Subject *"}),(0,a.jsxs)("select",{id:"subject",name:"subject",value:e.subject,onChange:i,required:!0,className:"w-full px-4 py-3 rounded-lg border border-stroke dark:border-stroke-dark bg-transparent text-dark dark:text-white outline-none focus:border-primary transition",children:[a.jsx("option",{value:"",children:"Select a subject"}),a.jsx("option",{value:"enrollment",children:"Enrollment Inquiry"}),a.jsx("option",{value:"subjects",children:"Subject Information"}),a.jsx("option",{value:"tutoring",children:"Tutoring Services"}),a.jsx("option",{value:"general",children:"General Question"}),a.jsx("option",{value:"other",children:"Other"})]})]}),(0,a.jsxs)("div",{children:[a.jsx("label",{htmlFor:"message",className:"block text-sm font-medium text-dark dark:text-white mb-2",children:"Message *"}),a.jsx("textarea",{id:"message",name:"message",value:e.message,onChange:i,required:!0,rows:6,className:"w-full px-4 py-3 rounded-lg border border-stroke dark:border-stroke-dark bg-transparent text-dark dark:text-white outline-none focus:border-primary transition resize-none",placeholder:"Tell us how we can help you..."})]}),a.jsx("button",{type:"submit",disabled:r,className:"w-full bg-primary text-white py-3 rounded-lg font-medium hover:bg-primary/90 transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed",children:r?(0,a.jsxs)(a.Fragment,{children:[a.jsx("div",{className:"animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white"}),"Sending..."]}):(0,a.jsxs)(a.Fragment,{children:[a.jsx(d,{size:20}),"Send Message"]})})]})]}),(0,a.jsxs)("div",{className:"space-y-8",children:[(0,a.jsxs)("div",{children:[a.jsx("h2",{className:"text-3xl font-bold text-dark dark:text-white mb-6",children:"Get in Touch"}),a.jsx("p",{className:"text-body-secondary text-lg leading-relaxed mb-6",children:"Have questions about our matric support programs? Want to know more about how we can help you achieve your academic goals? We're here to help!"}),a.jsx("p",{className:"text-body-secondary leading-relaxed",children:"Our dedicated team is ready to answer your questions and guide you through the enrollment process. Whether you're looking for information about specific subjects, tutoring schedules, or our teaching methods, don't hesitate to reach out."})]}),a.jsx("div",{className:"bg-primary/5 dark:bg-primary/10 p-6 rounded-lg border border-primary/20",children:(0,a.jsxs)("div",{className:"flex items-start gap-4 mb-4",children:[a.jsx(c,{className:"text-primary flex-shrink-0 mt-1",size:24}),(0,a.jsxs)("div",{children:[a.jsx("h3",{className:"text-lg font-bold text-dark dark:text-white mb-2",children:"Why Contact Us?"}),(0,a.jsxs)("ul",{className:"space-y-2 text-body-secondary text-sm",children:[a.jsx("li",{children:"• Get personalized course recommendations"}),a.jsx("li",{children:"• Learn about our enrollment process"}),a.jsx("li",{children:"• Schedule a consultation with our tutors"}),a.jsx("li",{children:"• Inquire about pricing and packages"}),a.jsx("li",{children:"• Ask about subject-specific support"}),a.jsx("li",{children:"• Request information about success rates"})]})]})]})}),(0,a.jsxs)("div",{className:"bg-green-50 dark:bg-green-900/20 p-6 rounded-lg border border-green-200 dark:border-green-800",children:[a.jsx("h3",{className:"text-lg font-bold text-dark dark:text-white mb-2",children:"Quick Response Guarantee"}),a.jsx("p",{className:"text-body-secondary text-sm",children:"We aim to respond to all inquiries within 24 hours during business days. For urgent matters, please call us directly during working hours."})]})]})]})]})})]})}},14323:(e,t,r)=>{"use strict";r.d(t,{Z:()=>o});var a=r(10326),s=r(90434);let o=({pageName:e,pageDescription:t})=>(0,a.jsxs)("div",{className:"dark:bg-darkmode relative z-10 overflow-hidden pb-[60px] pt-[120px] md:pt-[130px] lg:pt-[160px]",children:[a.jsx("div",{className:"from-stroke/0 via-stroke to-stroke/0 dark:via-dark-3 absolute bottom-0 left-0 h-px w-full bg-gradient-to-r"}),a.jsx("div",{className:"container mx-auto",children:a.jsx("div",{className:"-mx-4 flex flex-wrap items-center",children:a.jsx("div",{className:"w-full px-4",children:(0,a.jsxs)("div",{className:"text-center",children:[a.jsx("h1",{className:"text-black mb-4 text-3xl font-bold sm:text-4xl md:text-[40px] md:leading-[1.2] dark:text-white",children:e}),a.jsx("p",{className:"text-black dark:text-black-6 mb-5 text-base",children:t}),(0,a.jsxs)("ul",{className:"flex items-center justify-center gap-[10px]",children:[a.jsx("li",{children:a.jsx(s.default,{href:"/",className:"text-black flex items-center gap-[10px] text-base font-medium dark:text-white dark:text-opacity-50",children:"Home"})}),a.jsx("li",{children:(0,a.jsxs)("p",{className:"text-body-color flex items-center gap-[10px] text-base font-medium",children:[a.jsx("span",{className:"text-body-color dark:text-white dark:text-opacity-50",children:" / "}),e]})})]})]})})})})]})},17762:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>a});let a=(0,r(68570).createProxy)(String.raw`c:\Projects\kzm-matric-new\src\app\(site)\contact\page.tsx#default`)},40381:(e,t,r)=>{"use strict";r.d(t,{ZP:()=>H});var a,s=r(17577);let o={data:""},i=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||o},n=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,l=/\/\*[^]*?\*\/|  +/g,d=/\n+/g,c=(e,t)=>{let r="",a="",s="";for(let o in e){let i=e[o];"@"==o[0]?"i"==o[1]?r=o+" "+i+";":a+="f"==o[1]?c(i,o):o+"{"+c(i,"k"==o[1]?"":t)+"}":"object"==typeof i?a+=c(i,t?t.replace(/([^,])+/g,e=>o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):o):null!=i&&(o=/^--/.test(o)?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=c.p?c.p(o,i):o+":"+i+";")}return r+(t&&s?t+"{"+s+"}":s)+a},m={},p=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+p(e[r]);return t}return e},u=(e,t,r,a,s)=>{let o=p(e),i=m[o]||(m[o]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(o));if(!m[i]){let t=o!==e?e:(e=>{let t,r,a=[{}];for(;t=n.exec(e.replace(l,""));)t[4]?a.shift():t[3]?(r=t[3].replace(d," ").trim(),a.unshift(a[0][r]=a[0][r]||{})):a[0][t[1]]=t[2].replace(d," ").trim();return a[0]})(e);m[i]=c(s?{["@keyframes "+i]:t}:t,r?"":"."+i)}let u=r&&m.g?m.g:null;return r&&(m.g=m[i]),((e,t,r,a)=>{a?t.data=t.data.replace(a,e):-1===t.data.indexOf(e)&&(t.data=r?e+t.data:t.data+e)})(m[i],t,a,u),i},x=(e,t,r)=>e.reduce((e,a,s)=>{let o=t[s];if(o&&o.call){let e=o(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;o=t?"."+t:e&&"object"==typeof e?e.props?"":c(e,""):!1===e?"":e}return e+a+(null==o?"":o)},"");function h(e){let t=this||{},r=e.call?e(t.p):e;return u(r.unshift?r.raw?x(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,i(t.target),t.g,t.o,t.k)}h.bind({g:1});let g,b,f,y=h.bind({k:1});function k(e,t){let r=this||{};return function(){let a=arguments;function s(o,i){let n=Object.assign({},o),l=n.className||s.className;r.p=Object.assign({theme:b&&b()},n),r.o=/ *go\d+/.test(l),n.className=h.apply(r,a)+(l?" "+l:""),t&&(n.ref=i);let d=e;return e[0]&&(d=n.as||e,delete n.as),f&&d[0]&&f(n),g(d,n)}return t?t(s):s}}var j=e=>"function"==typeof e,v=(e,t)=>j(e)?e(t):e,w=(()=>{let e=0;return()=>(++e).toString()})(),N=((()=>{let e;return()=>e})(),"default"),P=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return P(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let o=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+o}))}}},q=[],z={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},_={},A=(e,t=N)=>{_[t]=P(_[t]||z,e),q.forEach(([e,r])=>{e===t&&r(_[t])})},C=e=>Object.keys(_).forEach(t=>A(e,t)),S=e=>Object.keys(_).find(t=>_[t].toasts.some(t=>t.id===e)),F=(e=N)=>t=>{A(t,e)},M={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},Z=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||w()}),$=e=>(t,r)=>{let a=Z(t,e,r);return F(a.toasterId||S(a.id))({type:2,toast:a}),a.id},E=(e,t)=>$("blank")(e,t);E.error=$("error"),E.success=$("success"),E.loading=$("loading"),E.custom=$("custom"),E.dismiss=(e,t)=>{let r={type:3,toastId:e};t?F(t)(r):C(r)},E.dismissAll=e=>E.dismiss(void 0,e),E.remove=(e,t)=>{let r={type:4,toastId:e};t?F(t)(r):C(r)},E.removeAll=e=>E.remove(void 0,e),E.promise=(e,t,r)=>{let a=E.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?v(t.success,e):void 0;return s?E.success(s,{id:a,...r,...null==r?void 0:r.success}):E.dismiss(a),e}).catch(e=>{let s=t.error?v(t.error,e):void 0;s?E.error(s,{id:a,...r,...null==r?void 0:r.error}):E.dismiss(a)}),e};var O=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,G=y`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,I=y`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,L=(k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${O} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${G} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${I} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,y`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`),T=(k("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${L} 1s linear infinite;
`,y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`),W=y`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,D=(k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${T} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${W} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,k("div")`
  position: absolute;
`,k("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,y`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`);k("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${D} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,k("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,k("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,a=s.createElement,c.p=void 0,g=a,b=void 0,f=void 0,h`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;var H=E}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[948,906,128],()=>r(14736));module.exports=a})();